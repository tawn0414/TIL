package basic;
public class TestMain {
	public static void main(String[] args) {
		Insa insa = new InsaImpl();
		MemberDTO user = new MemberDTO("jang","1234","�嵿��");
		insa.addUser(user);

	}

}
