package exam.anno02;

public interface Service {
	void test();
}
