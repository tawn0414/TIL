package exam.anno02;

public interface Logic {
	void testLogic();
}
