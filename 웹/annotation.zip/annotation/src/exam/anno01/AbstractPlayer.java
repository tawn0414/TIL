package exam.anno01;

public interface AbstractPlayer {
	void play();
	int getTotalValue();

}