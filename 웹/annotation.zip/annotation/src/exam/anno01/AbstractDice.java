package exam.anno01;

public interface AbstractDice {
	int getDiceValue();
}