package book.exam.constructor;

public interface Speaker {

	void soundUp();

	void soundDown();

}