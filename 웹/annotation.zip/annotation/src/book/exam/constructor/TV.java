package book.exam.constructor;

public interface TV {
	void turnOn();
	void turnOff();
	void soundUp();
	void soundDown();
}
