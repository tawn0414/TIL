package multi.android.network.chatting;

public class ChatMessage {
    String nickname;
    String msg;
}
